#!/bin/bash
# This script is run before the rpm files instllation.

echo "Pre install script started"

# write the script or call another script from within same folder
# bash ./myscipt.sh

echo "Pre install script ended"

