#!/bin/bash
# This script is run after the rpm files instllation.

echo "Post install script started"

# write the script or call another script from within same folder
# bash ./myscipt.sh

##### example to import dashboards #####
#### only run on Analytics VM
# . $ALIVE_BASE/user/conf/install/common.sh
# VMNAME=`getValueFromOVFCache "vm.vmname"`
# if [ "x$VMNAME" = "x$VM_2_NAME" ]; then
#     pushd $ALIVE_BASE/tools/dbcli
#     bash  ./dbcli.sh dashboard import admin $ALIVE_BASE/user/plugins/inbound/my_adapter3/conf/dashboards/Sample-Dashboard.xml
#     popd
# fi
########################################

echo "Post install script ended"
