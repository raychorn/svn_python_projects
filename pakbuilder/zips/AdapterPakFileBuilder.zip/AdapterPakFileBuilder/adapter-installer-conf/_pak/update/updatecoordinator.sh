#!/bin/bash
#
# updatecoordinator.sh [-d] [-f]
# This script orchestrates all the operations necessary for updating VCOps
# Use -f option to force update even if the update version/build is older than the current version/build
# Use -d option to disable starting vcops, vcopsweb and vcopsenterprise services after the update operation.
#
export ALIVE_BASE
. /usr/lib/vmware-vcops/user/conf/install/common.sh

readonly LOGFILE=/var/log/vmware/updatecoordinator.log
readonly STATUSFILE=/var/log/vmware/lastupdate.log
readonly UPDATELOCK=/var/lock/vmware/vcops-update.lck

readonly SSH_CMD="ssh -o StrictHostKeyChecking=no root@secondvm-internal"

# location where update bundle is unpacked. ex., /data/upd-tmp/vcops-update-xxx-unpacked
readonly UPDATEDIR=`dirname $0`

# Alternate temp location that is usually guaranteed to have sufficient space available
export TMPDIR=/data/upd-tmp

# location on remote VA where update bundle is copied. ex., /data/upd-tmp/vcops-update-xxx-unpacked
readonly REMOTEUPDATEDIR="$TMPDIR/"`basename $UPDATEDIR`
export REMOTEUPDATEDIR

readonly PRODUCT_VERSION=`cat $UPDATEDIR/manifest.txt | grep PRODUCT_VERSION | sed -e "s/PRODUCT_VERSION=//"`
readonly ADAPTER_VERSION=`cat $UPDATEDIR/manifest.txt | grep ADAPTER_VERSION | sed -e "s/ADAPTER_VERSION=//"`
readonly BUILD_NUMBER=`cat $UPDATEDIR/manifest.txt | grep BUILD_NUMBER | sed -e "s/BUILD_NUMBER=//"`

# Some constants for checking rpm install status
readonly RPM_NOT_INSTALLED=0
readonly RPM_ALREADY_INSTALLED=1
readonly RPM_OTHER_ERROR=2

# Will hold a list of all rpms in the update
ALLRPMFILES=

# Will hold list of names of non-admin rpms to install
RPMFILES=

# Will hold the name of the admin UI rpm
ADMINRPMFILES=

# Will hold the name of rpms that failed upgrade test
FAILEDRPMFILES=

#
# Log a message
#
log_info()
{
    echo "`date` [INFO] $1"
}

#
# Log an error
#
log_error()
{
    echo "`date` [ERROR] $1"
}

#
# Write the status message into update status file
#
update_status()
{
    local marker1='.............................................................'
    local marker2='.......'
    # Print fixed width with dots separating the task and status
    printf "%s %s%s %s\n" "$1" "${marker1:${#1}}" "${marker2:${#2}}" "$2" >> $STATUSFILE
}

#
# If last command returned error, write the error message to log file, status file
# and stop the update process
#
stop_on_error()
{
    err=$?
    if [ "$err" -ne 0 ]; then
        log_error_and_stop "$err" "$1"
    fi
}

#
# log error and stop update process
#
log_error_and_stop()
{
    err=$1
    log_error "Command returned $err"
    log_error "$2 failed"
    update_status "$2" "failed!"
    update_status "Update operation" "failed!"
    exit $err
}

#
# drop a lock to indicate update in progress
#
set_update_lock()
{
    mkdir $UPDATELOCK
    stop_on_error "Preparing update environment"
}

#
# remove update lock
#
unset_update_lock()
{
    rmdir $UPDATELOCK
}

#
# Get the install status of the specified rpm
# Return code indicates the status
#
get_rpm_install_status()
{
    local exitcode
    local outcome
    local rpm="$1"
    outcome=`rpm --upgrade --test $rpm 2>&1`
    exitcode=$?

    # print test output for diagnostics
    if [ "x$outcome" != "x" ]; then
        log_info "Test result for $rpm: $outcome"
    fi

    # Because rpm doesn't return meaningful exit codes, we rely on the output text
    if [ "$exitcode" -eq 0 ]; then
        return $RPM_NOT_INSTALLED
    elif [[ "$outcome" =~ "already installed" ]]; then
        return $RPM_ALREADY_INSTALLED
    else
        return $RPM_OTHER_ERROR
    fi
}

#
# Filter out installed rpms from the list of all rpms
#
filter_installed_rpms()
{
    local file
    local exitcode
    local outputfiles

    for file in $ALLRPMFILES; do
        local RPM=`basename $file`
        get_rpm_install_status "$file"
        exitcode=$?
        if [ "$exitcode" == $RPM_NOT_INSTALLED ]; then
            outputfiles="$outputfiles $file"
        elif [ "$exitcode" == $RPM_ALREADY_INSTALLED ]; then
            log_info "$RPM or a newer version of it is already installed and will be skipped"
        else
            log_error "$RPM has failed validation test"
            FAILEDRPMFILES="$FAILEDRPMFILES $file"
        fi
    done

    # Filtered list of rpms
    ALLRPMFILES="$outputfiles" 
}

#
# Group the list of all rpms into admin and non-admin rpms
# This will be used to separately install the group of rpms
#
group_rpms()
{
    local file

    for file in $ALLRPMFILES; do
        local RPM=`basename $file`
        if expr match "$RPM" '^vmware-vcops-admin-web-.*' > /dev/null; then
            ADMINRPMFILES="$ADMINRPMFILES $RPM"
        else
            RPMFILES="$RPMFILES $RPM"
        fi
    done
    log_info "Admin rpms to install: $ADMINRPMFILES"
    log_info "Non-admin rpms to install: $RPMFILES"
}

#
# Get all the rpms that can be installed and group them as admin and non-admin
#
get_rpms_to_install()
{
    log_info "Determining the rpms to be installed"

    ALLRPMFILES=`ls $UPDATEDIR/*.rpm 2>/dev/null`
    if [ "x$ALLRPMFILES" == "x" ]; then
        log_info "No rpms to install"
        return
    fi

    # If force install not specified, filter out rpms for which the same or
    # higher version is already installed
    if [ "x$RPMFORCE"  == "x" ]; then
        filter_installed_rpms
    else
        log_info "force option specified. Will attempt to install all rpms"
    fi

    # If there were errors detected during filtering, bail out
    if [ "x$FAILEDRPMFILES" != "x" ]; then
        return
    fi

    # bucket the rpms into admin and non-admin groups
    group_rpms
}


#
# Upgrade rpms locally and if required on remote VA
#
upgrade_rpms()
{
    local TO_INSTALL="$1"
    if [ "x$TO_INSTALL" != "x" ]; then
        log_info "Testing rpm(s) $TO_INSTALL"
        pushd $UPDATEDIR; rpm --upgrade $RPMFORCE --quiet --test $TO_INSTALL
        stop_on_error "Installing update"
        popd

        log_info "Upgrading rpm(s) $TO_INSTALL"
        pushd $UPDATEDIR; rpm --upgrade $RPMFORCE $TO_INSTALL
        stop_on_error "Installing update"
        popd

        if [ "x$VMNAME" = "x$VM_1_NAME" ]; then
            log_info "Upgrading rpm(s) on $VM2_DISPLAY_NAME"
            $SSH_CMD "export TMPDIR=$TMPDIR; export REMOTEUPDATEDIR=$REMOTEUPDATEDIR; cd $REMOTEUPDATEDIR; rpm --upgrade $RPMFORCE $TO_INSTALL"
            stop_on_error "Installing update"
        fi
    else
        log_info "No rpms to install"
    fi
    update_status "Installing update" "done"
}


#
# Do cleanup before clean or unclean termination
#
cleanup()
{
    log_info "Cleaning up"

    # first reset signal handler
    trap - HUP INT QUIT TERM EXIT

    unset_update_lock

    # In case we errored out before the fixup step, take care of this
    chown -R $VCOPS_USER:$VCOPS_GROUP $ALIVE_BASE

    if [ "x$VMNAME" = "x$VM_1_NAME" ]; then
        $SSH_CMD "rm -rf $REMOTEUPDATEDIR; chown -R $VCOPS_USER:$VCOPS_GROUP $ALIVE_BASE"
    fi

    # pop out in case we trapped while inside $UPDATEDIR, which is about to be trashed
    popd 2>/dev/null

    #remove update directory
    rm -rf $UPDATEDIR 2>/dev/null

    exit
}

#
# Main driver
#
main()
{
    if [ "`whoami`" != "root" ]; then
        log_error "This program must be run as root"
        update_status "Validating update environment" "failed!"
        exit 1
    fi

    set_update_lock

    # Create our custom TMPDIR if it doesn't exit (it should really)
    mkdir -p $TMPDIR

    if [ "x$ALIVE_BASE" = "x" ]; then
        ALIVE_BASE=/usr/lib/vmware-vcops
    fi

    # 2 VA setup, log all installed adapter versions for debugging
    if [ "x$VMNAME" = "x$VM_1_NAME" ]; then
       local INSTALLED_ADAPTERS=`$SSH_CMD "rpm -qa|grep -i adapter"`
       log_info "Installed adapters: $INSTALLED_ADAPTERS"
    fi
    log_info "Upgrading to version: $ADAPTER_VERSION build $BUILD_NUMBER"

    # Detect current VA configuration
    VMNAME=`getValueFromOVFCache 'vm.vmname'`
    if [ "x$VMNAME" = "x$VM_2_NAME" ]; then
        log_error "This program must be run from the primary VA"
        update_status "Validating update environment" "failed!"
        exit 1
    fi

    # setup cleanup handler upon signal or exit
    trap cleanup HUP INT QUIT TERM EXIT

    # Get list of rpms that can be installed
    get_rpms_to_install

    if [ "x$FAILEDRPMFILES" != "x" ]; then
        log_error "Following rpms failed validation test: $FAILEDRPMFILES"
        update_status "Validating update files" "failed!"
        exit 1
    fi

    if [ "x$ADMINRPMFILES" == "x" -a "x$RPMFILES" == "x" ]; then
        log_info "No rpms to install"
        update_status "No update files to install !"
        exit 0
    fi

    update_status "Validating update files" "done"

    # 2-VA setup; copy update files over to secondary VA
    if [ "x$VMNAME" = "x$VM_1_NAME" ]; then
        log_info "Copying directory $UPDATEDIR to remote VA at $TMPDIR"
        $SSH_CMD "mkdir -p $TMPDIR"
        scp -o StrictHostKeyChecking=no -r $UPDATEDIR root@secondvm-internal:$TMPDIR
        stop_on_error "Preparing update environment"
    fi

    upgrade_rpms "$RPMFILES"

    log_info "Performing post-install steps"

    # Change ownership back to admin if they are changed due to rpm install
    chown -R $VCOPS_USER:$VCOPS_GROUP $ALIVE_BASE

    if [ "x$VMNAME" = "x$VM_1_NAME" ]; then
        $SSH_CMD "chown -R $VCOPS_USER:$VCOPS_GROUP $ALIVE_BASE"
    fi

    update_status "Update operation" "done"
    exit 0
}

############################### Start execution ###############################

RPMFORCE=--force

# setup logging. send stdout and stderr to terminal and log file
exec > >(tee -a $LOGFILE)
exec 2>&1

# apparently getopts doesn't like to work if invoked within a function
# so do it as the first thing
while getopts "dfs" flag; do
    case "$flag" in
        "f") RPMFORCE=--force ;;
    esac
done

main

