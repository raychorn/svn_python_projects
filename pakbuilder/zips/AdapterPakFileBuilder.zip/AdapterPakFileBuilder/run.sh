#!/bin/bash
#
ant -buildfile adapter-installer-conf/adapter-build.xml build.pak;
exit;



