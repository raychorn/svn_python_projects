__copyright__ = """\
(c). Copyright 2008-2012, Vyper Logix Corp., All Rights Reserved.

Published under Creative Commons License 
(http://creativecommons.org/licenses/by-nc/3.0/) 
restricted to non-commercial educational use only., 

http://www.VyperLogix.com for details

THE AUTHOR VYPER LOGIX CORP DISCLAIMS ALL WARRANTIES WITH REGARD TO
THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND
FITNESS, IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL,
INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING
FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT,
NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION
WITH THE USE OR PERFORMANCE OF THIS SOFTWARE !

USE AT YOUR OWN RISK.
"""
import os, sys

from vyperlogix import misc
from vyperlogix.misc import _utils
from vyperlogix.hash.lists import HashedLists2
from vyperlogix.crypto import blowfish
from vyperlogix.classes import SmartObject

from vyperlogix.enum import Enum

from vyperlogix import oodb

from vyperlogix import ssl

__passphrase__ = 'P{nXJ$*!GOilkadd:=NDoo/az*@$A33\'`AI[&ip8R|f\\Oj|\\&*][?f1%S$9/HMn"G(v1bHVq2wNlI)Zou7(%B^_ZZ<_~o:K!Sw<9!9<{zT=3J>?Oz+7A=y9e#\'rDBnF:'

#__passphrase__ = 'V~scHqj]V$HdCe/)34"3dN:gAcT`uJrk&-Kt1}mqb"_y;0W=5$jnVi|_'

# __url__ = 'https://raychorn.webfactional.com/media/BD24E60DDE454995/3BFA2BBA2E9495E40817E19CAAF9C8112621BE0A198D8010'

# __url2__ = 'https://raychorn.webfactional.com/media/BD24E60DDE454995.1/3BFA2BBA2E9495E40817E19CAAF9C8112621BE0A198D8010'

#xx = oodb.strToHex(blowfish.encryptData(__url2__, __passphrase__))

__url__ = 'CE0D94C610C0E1D512E721DB6774589FC2C6AA3EAFB41C1C57F66B2F2C5C42C36B8B901A3EA4C12D52841ABC5D9D956FAD88FC9E7C85D55544D0A69F1CC1C61756D893222358D7132DC8F767B47AC0FC75CAB5B6E0EF04B6F076BFB994A9428CB074F51D63B5175D9AFD010CA6379A35'

__url2__ = 'CE0D94C610C0E1D512E721DB6774589FC2C6AA3EAFB41C1C57F66B2F2C5C42C36B8B901A3EA4C12D52841ABC5D9D956FAD88FC9E7C85D55518DC6F4B9F3999ED4E826ABCF10AA920B60A6D0AA69FAE6BC436E9EE10F3C555755284CC6D3238B874F2341D05FC8284ED5294126B7E16CE'

class Methods(Enum.Enum):
    none = 0
    default = 2^0
    improved = 2^2

def _url_():
    return _utils.ascii_only(blowfish.decryptData(oodb.hexToStr(__url__), __passphrase__))

def _url2_():
    return _utils.ascii_only(blowfish.decryptData(oodb.hexToStr(__url2__), __passphrase__))

def unweave_from(contents):
    from vyperlogix.iterators import iterutils
    target = []
    phrase = []
    for t in iterutils.itergroup([i for i in contents.strip()], 4):
        _t_ = list(t)
        n = len(_t_)/2
        target.append(''.join(_t_[0:n]))
        phrase.append(''.join(_t_[n:]))
    return (''.join(target),''.join(phrase))

def __get_aws_credentials__(contents,method=Methods.default):
    from vyperlogix.iterators import iterutils
    _contents_,passphrase = (contents,None)
    if (method is Methods.improved):
        _contents_,passphrase = unweave_from(contents)
        passphrase = oodb.hexToStr(passphrase) if (misc.isString(passphrase)) else __passphrase__
        assert passphrase == __passphrase__, 'WARNING: Something has gone wrong with the passPhrase.'
        contents = blowfish.decryptData(oodb.hexToStr(_contents_), passphrase)
        contents = contents.split(chr(0x00))[0]
    d = HashedLists2(fromDict=dict([tt.split('=') for tt in [t.strip() for t in contents.split('\n')] if (len(tt) > 0)]))
    if (method is not Methods.improved):
        for k,v in d.iteritems():
            _k_ = _utils.ascii_only(blowfish.decryptData(oodb.hexToStr(k), __passphrase__))
            d[_k_] = _utils.ascii_only(blowfish.decryptData(oodb.hexToStr(v), __passphrase__))
            del d[k]
    return SmartObject.SmartFuzzyObject(args=d.asDict(isCopy=True))

def get_aws_credentials(filename='./credentials_secure.txt',url=None,method=Methods.default):
    '''
    filename specifies a file name for the encrypted credentials file.
    '''
    soCredentials = None
    if (filename is None) and (url is None):
        url = _url_()
    if (misc.isString(filename)) and (os.path.exists(filename)):
        try:
            c = _utils.readBinaryFileFrom(filename)
        except:
            c = ''
    elif (misc.isString(url)):
        try:
            c = ssl.fetch_from_ssl(url)
        except:
            c = ''
    return __get_aws_credentials__(c,method=method)

def weave_into(target,phrase):
    from vyperlogix.iterators import iterutils
    normalize = lambda foo,m:foo+('00'*(m-(len(foo)/2)) if ((len(foo)/2) < m) else '')
    results = []
    target = _utils.ascii_only(target)
    phrase = _utils.ascii_only(phrase)
    m = max(len(target)/2,len(phrase)/2)
    m += m % 2
    target = normalize(target,m)
    phrase = normalize(phrase,m)
    assert len(target) == len(phrase), 'ERROR: Something went wrong with the normalization in %s' % (misc.funcName())
    pGen = (pCh for pCh in iterutils.itergroup([p for p in phrase], 2))
    for t in iterutils.itergroup([i for i in target], 2):
        results.append(''.join(t))
        results.append(''.join(pGen.next()))
    return ''.join(results)

if (__name__ == '__main__'):
    ##################################################
    # BEGIN: Gen a new passphrase 
    ##################################################
    #from vyperlogix.misc import GenPasswd
    #_pass_ = GenPasswd.GenPasswd(length=448/8,chars=GenPasswd.chars_printable)
    #print _pass_
    ##################################################
    # END!    Gen a new passphrase 
    ##################################################

    #toks = _url_().split('/')
    #t2 = oodb.strToHex(blowfish.encryptData(toks[-2], __passphrase__))
    #print '%s=%s' % (toks[-2],t2)
    #t1 = oodb.strToHex(blowfish.encryptData(toks[-1], __passphrase__))
    #print '%s=%s' % (toks[-1],t1)
    #_u_ = oodb.strToHex(blowfish.encryptData(_url_(), __passphrase__))
    #print _u_

    #if (0):
        #fname = os.path.abspath('./credentials.txt')
        #toks = list(os.path.splitext(fname))
        #toks[0] += '_secure'
        #fnameOut = ''.join(toks)
        #method = Methods.default
        #if (not os.path.exists(fnameOut)):
            #io = _utils.stringIO()
            #if (os.path.exists(fname)):
                #c = _utils.readBinaryFileFrom(fname)
                #d = HashedLists2(fromDict=dict([tt.split('=') for tt in [t.strip() for t in c.split('\n')] if (len(tt) > 0)]))
            #else:
                #soCredentials = get_aws_credentials(url=_url_(),filename=None)
                #d = HashedLists2(fromDict=soCredentials.asPythonDict())
                #method = Methods.improved
            #f_out = open(fnameOut, mode='wb', buffering=1)
            #dE = d.asDict(isCopy=True)
            #for k,v in dE.iteritems():
                #_k_ = oodb.strToHex(blowfish.encryptData(k, __passphrase__))
                #del dE[k]
                #_v_ = oodb.strToHex(blowfish.encryptData(v, __passphrase__))
                #dE[_k_] = _v_
                #print >>io, '%s%s%s' % (k,'=',v)
            #_contents_ = weave_into(oodb.strToHex(blowfish.encryptData(io.getvalue(), __passphrase__)),oodb.strToHex(__passphrase__))
            #print >> f_out, _contents_
            #f_out.flush()
            #f_out.close()
            #soCredentials2 = __get_aws_credentials__(_contents_,method=method)
            #assert soCredentials.AWSAccessKeyId == soCredentials2.AWSAccessKeyId, 'WARNING: Something is wrong with the Improved method.'
            #assert soCredentials.AWSSecretKey == soCredentials2.AWSSecretKey, 'WARNING: Something is wrong with the Improved method.'
            #dP = HashedLists2(fromDict=dE).asDict()
            #for k,v in dP.iteritems():
                #_k_ = _utils.ascii_only(blowfish.decryptData(oodb.hexToStr(k), __passphrase__))
                #dP[_k_] = _utils.ascii_only(blowfish.decryptData(oodb.hexToStr(v), __passphrase__))
                #del dP[k]
                #assert dP[_k_] == d[_k_], 'WARNING: Expected %s to match %s.' % (dP[_k_],d[_k_])
        #if (os.path.exists(fnameOut)):
            #soCredentials = get_aws_credentials(filename='./credentials_secure.txt',method=method)

    if (1):
        soCredentials = get_aws_credentials(url=_url_(),filename=None,method=Methods.default)
        soCredentials2 = get_aws_credentials(url=_url2_(),filename=None,method=Methods.improved)
        assert soCredentials.AWSAccessKeyId == soCredentials2.AWSAccessKeyId, 'WARNING: Something is wrong with the Improved method.'
        assert soCredentials.AWSSecretKey == soCredentials2.AWSSecretKey, 'WARNING: Something is wrong with the Improved method.'

    from boto.s3 import connection
    aConnection = connection.S3Connection(aws_access_key_id=soCredentials2.AWSAccessKeyId, aws_secret_access_key=soCredentials2.AWSSecretKey)
    buckets = aConnection.get_all_buckets()
    print 'buckets=%s' % (buckets)
    pass