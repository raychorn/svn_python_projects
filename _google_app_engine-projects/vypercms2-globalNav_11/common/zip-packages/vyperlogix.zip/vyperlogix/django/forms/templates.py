def template_for_form(form_html):
    from django.template import Template
    return Template(form_html)
