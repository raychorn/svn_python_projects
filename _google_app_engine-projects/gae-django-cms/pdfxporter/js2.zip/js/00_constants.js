// constants.js

var const_inline_style = 'inline';
var const_none_style = 'none';
var const_block_style = 'block';

var const_absolute_style = 'absolute';
var const_relative_style = 'relative';

var $cache = [];

var const_function_symbol = 'function';

var const_object_symbol = 'object';
var const_number_symbol = 'number';
var const_string_symbol = 'string';

var const_debug_symbol = 'DEBUG';
var const_error_symbol = 'ERROR';

var const_simpler_symbol = 'simpler';
