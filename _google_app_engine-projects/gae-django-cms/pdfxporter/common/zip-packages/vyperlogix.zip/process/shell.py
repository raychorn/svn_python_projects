__copyright__ = """\
(c). Copyright 2008-2012, Vyper Logix Corp., All Rights Reserved.

Published under Creative Commons License 
(http://creativecommons.org/licenses/by-nc/3.0/) 
restricted to non-commercial educational use only., 

http://www.VyperLogix.com for details

THE AUTHOR VYPER LOGIX CORP DISCLAIMS ALL WARRANTIES WITH REGARD TO
THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND
FITNESS, IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL,
INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING
FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT,
NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION
WITH THE USE OR PERFORMANCE OF THIS SOFTWARE !

USE AT YOUR OWN RISK.
"""
import os,sys

from vyperlogix import misc
from vyperlogix.misc import _utils
from vyperlogix.http import downloadFileFromURL

from vyperlogix.classes import CooperativeClass

class SmartShell(CooperativeClass.Cooperative):
    def __init__(self,command=None,callback=None,isDebugging=False,onExit=None,sysout=sys.stderr):
	self.__sysout__ = sysout
	self.__isDebugging__ = isDebugging
	self.__callback__ = callback
	self.__onExit__ = onExit
	self.__command__ = command
	    
    def execute(self,command=None,callback=None,onExit=None):
	from vyperlogix.os.shell import Shell
	if (callable(callback)):
	    self.__callback__ = callback
	if (callable(onExit)):
	    self.__onExit__ = onExit
	def callback1(data):
	    if (callable(self.__callback__)):
		try:
		    self.__callback__(self,data=data)
		except Exception, ex:
		    info_string = _utils.formattedException(details=ex)
		    print >> self.__sysout__, info_string
	def onExit():
	    if (callable(self.__onExit__)):
		try:
		    self.__onExit__(self)
		except Exception, ex:
		    info_string = _utils.formattedException(details=ex)
	if (self.__isDebugging__):
	    print >> self.__sysout__, 'DEBUG: %s' % (self.__command__)
	self.__shell__ = Shell(self.__command__,callback=callback1,isDebugging=self.isDebugging,isExit=True,isWait=False,onExit=onExit)

    def command():
        doc = "get the command."
        def fget(self):
            return self.__command__
        def fset(self,command):
	    self.__command__ = command
        return locals()
    command = property(**command())

    def sysout():
        doc = "get the sysout."
        def fget(self):
            return self.__sysout__
        def fset(self,sysout):
	    self.__sysout__ = sysout
        return locals()
    sysout = property(**sysout())

    def callback():
        doc = "set/get the calllback."
        def fget(self):
            return self.__callback__
        def fset(self,callback):
	    if (callable(callback)):
		self.__callback__ = callback
        return locals()
    callback = property(**callback())

    def isDebugging():
        doc = "get the isDebugging."
        def fget(self):
            return self.__isDebugging__
        def fset(self,isDebugging):
	    self.__isDebugging__ = isDebugging if (isDebugging) else False
        return locals()
    isDebugging = property(**isDebugging())

    def onExit():
        doc = "get the onExit."
        def fget(self):
            return self.__onExit__
        def fset(self,onExit):
	    if (callable(onExit)):
		self.__onExit__ = onExit
        return locals()
    onExit = property(**onExit())

################################################################################################

if (__name__ == "__main__"):
    def __callback__(ss,data=None):
	if (data) and (misc.isString(data)) and (len(data) > 0):
	    print 'BEGIN:'
	    print 'data=%s' % (data)
	    print 'END !'
    def __onExit__(ss):
	print 'BEGIN:'
	print 'END !'
    ss = SmartShell('dir c:\\',callback=__callback__,isDebugging=True,onExit=__onExit__,sysout=sys.stdout)
    ss.execute()
