is_checkbox_value_true = lambda value:str(value).lower() in ['true','1','yes','ok']
