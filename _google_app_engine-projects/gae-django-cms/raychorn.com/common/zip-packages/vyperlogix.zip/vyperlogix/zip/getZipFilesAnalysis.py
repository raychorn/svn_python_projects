from vyperlogix.zip import getZipFilesAnalysis

from vyperlogix.zip import getZipFilesAnalysis2
