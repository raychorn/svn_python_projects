import os

_data_path_prefix = lambda name:os.sep.join(['www.VyperLogix.com',name])
