function jsTest() {
	alert("JS test");
}